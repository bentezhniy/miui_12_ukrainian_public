#
**Description in English:**
#

This is the repository of the **Ukrainian**  translation of **Chinese MIUI**. 
At the moment it is used by **xiaomi.eu**  and **MiRoom**  teams.

**Contributors:** 
- bentezhniy;
- romanua90;
- AlexPechkin228;
- ishkornik.
- Andrex2287.
#
**Опис українською:**
#

Це репозиторій **українського**  перекладу **китайських MIUI**.
На даний момент він використовується командами **xiaomi.eu**  та **MiRoom**.

**Перекладачі:**
- bentezhniy;
- romanua90;
- AlexPechkin228;
- ishkornik.
- Andrex2287.




